// ----------------------------------------------------------------------

const account = {
  displayName: 'Yassine A.',
  email: 'demo@minimals.cc',
  photoURL: '/assets/images/avatars/avatar_default.jpg',
};

export default account;
