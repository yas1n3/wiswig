export const addNewsletter = (requestBody) => async (dispatch, getState) => {
    try {
        const response = await fetch('http://localhost:4000/newsletter/add_newsletter', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${getState().auth.token}`, // get the token from the Redux store
            },
            // credentials: 'include', // include cookies in the request
            body: JSON.stringify(requestBody),
        });

        if (response.ok) {
            const data = await response.json();
            dispatch({ type: 'ADD_NEWSLETTER_SUCCESS', payload: data });
        } else {
            const errorData = await response.json();
            dispatch({ type: 'ADD_NEWSLETTER_FAILURE', payload: errorData });
        }
    } catch (error) {
        dispatch({ type: 'ADD_NEWSLETTER_FAILURE', payload: error.message });
    }
};
